# Build APK บนมือถือด้วย GitHub Actions

1. สร้าง GitHub repository ชื่อ `calorie-buddy-pro`
2. อัปโหลดไฟล์ทั้งหมดของโปรเจกต์ V13.2 เข้า repository โดยต้องรักษาโครงสร้างโฟลเดอร์
3. ไปที่แท็บ **Actions**
4. เลือก workflow **Build Calorie Buddy Pro APK**
5. กด **Run workflow**
6. รอจนงานขึ้นสถานะสำเร็จ
7. เปิด workflow run ที่สำเร็จ แล้วไปที่ **Artifacts**
8. ดาวน์โหลด `calorie-buddy-pro-v13.2-apk`
9. แตก ZIP แล้วจะพบ `app-release.apk`
10. เปิด APK บน Android เพื่อติดตั้ง

หมายเหตุ:
- Workflow นี้สร้าง APK release สำหรับทดสอบบนเครื่องจริง
- ยังไม่ได้เซ็นด้วย keystore ส่วนตัวของเจ้าของแอป
- สำหรับ Google Play ต้องสร้าง signed AAB ด้วย Play App Signing/keystore ของเจ้าของแอป
