# Calorie Buddy V13 — Android / Play Store Project

This project wraps the current Calorie Buddy Real App UI (V12) inside a native Android WebView shell.

## Brand standard
- App name: Calorie Buddy Pro
- Package: com.caloriebuddy.pro
- Version: 1.0.0 / versionCode 13
- UI: existing Calorie Buddy mint/white wellness UI
- Icon: the current first-style Calorie Buddy icon supplied in the project

## Current architecture
HTML/CSS/JS remains the product UI and local data layer.
Android provides:
- native launcher/app shell
- secure local WebView asset origin
- camera permission bridge
- image/file chooser
- Android back navigation
- Play Store AAB release structure

Android WebView is an intentional choice here because the existing product is already a mobile web app and Android officially supports WebView for embedding web content controlled by the app.

## Build environment
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.3.21
- compileSdk 36
- targetSdk 36
- minSdk 23
- JDK 17

## Open in Android Studio
1. Install Android Studio compatible with Android 16 SDK.
2. Install Android SDK Platform 36 and Build Tools 36.
3. Open this folder as an existing Gradle project.
4. Let Gradle sync.
5. Run `app` on an Android phone/emulator.
6. For Play Store, choose Build > Generate Signed App Bundle / APK.
7. Choose Android App Bundle (AAB) for Google Play.
8. Create or select your upload keystore.
9. Build the release AAB.

## Important before Play Store submission
- Replace the placeholder signing configuration with your own secure upload key.
- Create a privacy policy URL if your final feature set/analytics requires one.
- Add final Play Store screenshots, description, app category, content rating and Data safety declarations.
- Test camera, file upload, offline behavior, Android back, rotation/lifecycle and WebView behavior on real devices.
- Complete Google Play developer verification as required.
- New apps submitted to Google Play from Aug 31, 2026 must target Android 16 / API 36 or higher.

## Expected output
`app-release.aab` — the preferred Google Play upload artifact.
`app-release.apk` — useful for direct device testing/distribution.

This project is a release-ready Android source structure, not a signed Play Store submission. A real release AAB must be signed with the developer's own key and uploaded through the developer's Play Console account.


## V13.2 Final APK Build Edition
- Splash Screen
- Android system bar polish
- Final version 1.2.0 / versionCode 132
- Added tools/build_release_apk.bat for Windows release APK build
