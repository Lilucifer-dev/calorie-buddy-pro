@echo off
setlocal
cd /d "%~dp0.."
echo === Calorie Buddy Pro V13.2 - Release APK ===
echo Checking Gradle wrapper...
if not exist gradlew.bat (
  echo gradlew.bat not found. Open the project in Android Studio and sync Gradle first.
  pause
  exit /b 1
)
call gradlew.bat clean assembleRelease
if errorlevel 1 (
  echo Build failed. Check Android SDK 36 and JDK 17 in Android Studio.
  pause
  exit /b 1
)
echo.
echo APK build complete:
echo app\build\outputs\apk\release\app-release.apk
pause
