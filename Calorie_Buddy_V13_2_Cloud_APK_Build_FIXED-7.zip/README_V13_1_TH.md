# Calorie Buddy Pro V13.1 — Android Test Build

## เป้าหมาย
เวอร์ชันนี้ปรับจาก V13 ให้พร้อมสำหรับการทดสอบบน Android จริงก่อนทำ Release/AAB

### ตรวจ/ปรับแล้ว
- ชื่อแอป: **Calorie Buddy Pro**
- Package ID: `com.caloriebuddy.pro`
- Version: `1.1.0` / versionCode `131`
- Target/Compile SDK: 36
- ไอคอน Launcher ใช้ชุด avocado/mint เดิม และมี adaptive icon สำหรับ Android รุ่นใหม่
- กล้อง: ขอ CAMERA permission และส่งผลการอนุญาตกลับให้ WebView อย่างถูกต้อง
- อัปโหลดรูป: รองรับ Android document picker
- ปุ่ม Back: ย้อนหน้าใน WebView ก่อนปิดแอป
- LocalStorage/DOM storage: เปิดใช้งาน และ restore WebView state เมื่อ Activity ถูกสร้างใหม่
- UI: portrait + edge-safe status/navigation bars + adjustResize
- ไม่เปิด cleartext HTTP
- WebView assets ถูกโหลดจาก Android WebViewAssetLoader

## ทดสอบจริง
1. เปิดโปรเจกต์ใน Android Studio
2. ติดตั้ง SDK 36 และ JDK 17
3. Sync Gradle
4. Run บนโทรศัพท์ Android จริง
5. ทดสอบ:
   - เปิดแอป/ไอคอน
   - เพิ่มอาหาร
   - ปิด/เปิดแอปแล้วดูข้อมูลที่บันทึกไว้
   - ถ่ายรูปอาหาร
   - อัปโหลดรูปจาก Gallery/Files
   - เปิด Barcode
   - กด Back จากหน้ารองกลับหน้าก่อนหน้า
   - หมุนหน้าจอ/กลับจาก background แล้วตรวจข้อมูล
6. เมื่อผ่านแล้วจึงสร้าง Signed APK/AAB

> หมายเหตุ: Smart Meal AI ใน HTML ยังเป็น prototype สำหรับ workflow; ยังไม่ใช่ระบบ Vision AI ที่วิเคราะห์รูปอาหารจริง


## V13.2 Final APK Build Edition
- Splash Screen
- Android system bar polish
- Final version 1.2.0 / versionCode 132
- Added tools/build_release_apk.bat for Windows release APK build
