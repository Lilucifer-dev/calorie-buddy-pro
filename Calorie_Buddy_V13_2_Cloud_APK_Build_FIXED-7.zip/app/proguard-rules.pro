# Calorie Buddy V13
# Keep WebView/JS bridge classes if a future native bridge is added.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
